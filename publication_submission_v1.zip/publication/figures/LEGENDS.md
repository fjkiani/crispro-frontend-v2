# Figure Legends

F2. Target‑Lock heatmap across metastatic mission steps and target genes. Heatmap shows mission‑aware Target‑Lock scores (0–1) for 8 steps × 7 genes. Component contributions (Functionality 0.35, Essentiality 0.35, Chromatin 0.15, Regulatory 0.15) are detailed in the supplement. Values reflect normalized, threshold‑gated signals (≥0.6) and are clipped to [0,1].

F2 (Supplement). Component score breakdown per mission × gene. Four panels display Functionality, Essentiality, Chromatin, and Regulatory signals (0–1), illustrating contributions that produce the Target‑Lock score in F2.

F3. Guide efficacy distributions by mission step. Violin plots summarize Evo2 delta→sigmoid efficacy scores for designed guides (n as indicated). Mean ± SD shown; decimal precision matches Table 2.

F4. Guide safety distributions by mission step. Violin plots summarize genome‑wide safety scores derived from minimap2/BLAST off‑target counts with exponential decay mapping (safety = exp(−0.5×hits)). Mean ± SD shown.

F5. Assassin composite score distributions by mission step. Box plots show composite scores (0.40×efficacy + 0.30×safety + 0.30×mission fit). Whiskers denote interquartile ranges; medians labeled; decimals match Table 2.
