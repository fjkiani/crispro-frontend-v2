# Discussion

Intervention (future work): We will extend this Interception framework with an assessment-first paper that validates the Intervention (risk assessment) pipeline against clinical outcomes. That work will integrate production Enformer/Borzoi for chromatin, AlphaFold 3 for structural assessment of designed constructs, disease-specific rulesets, and cohort priors, and will report calibration/validation metrics.
